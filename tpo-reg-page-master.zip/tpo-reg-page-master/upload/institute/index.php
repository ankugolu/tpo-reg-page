<?php
    header('Location: ./../404.shtml');
