TPO-REG-PAGE
======
Central Placement Committee, West Bengal (CPC), is a team of highly motivated and dedicated individuals from different Institutes of West Bengal, who selflessly and relentlessly work for providing placement supports and opportunities to the meritorious and enthusiastic students who are mainly located in rural belts along with other main region where the opportunities are limited.

Placement Committee supervises and manages the whole placement process which includes but is not limited to interacting with the recruitment company HR representatives, reaching out to Institutes/Universities for required students database based on company’s eligibility conditions/criteria, arranging necessary infrastructure to conduct the placement drive for all students of West Bengal.

CPC strives to maintain Corporate relations with the potential recruiters, develop a sense of trust, belief amongst the industries wrt West Bengal and its immense talent pool, maintain Database of Companies and establishing strategic links for campus recruitment, get in touch with corporate, start-ups for different sectors and tap in opportunities and lastly, to assist recruiters to achieve their hiring goals.

___
Website link: [www.cpcbengal.co.in](http://www.cpcbengal.co.in/)
___
