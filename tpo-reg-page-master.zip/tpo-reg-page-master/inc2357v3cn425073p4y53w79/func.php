<?php

    /**
     * Includes All classes and functions
     * 
     * Created by IntelliJ IDEA.
     * User: Arkadip
     * Date: 10/02/18
     * Time: 04:35 PM 
    */

    if(defined('_incFuncwwrfbhdjrt')){

        //error_reporting(0);

        session_name('cpc');
        session_start();
        
        date_default_timezone_set("Asia/Calcutta");

        define('INC',dirname(__FILE__));

        define('_FUNCrqwetwegww', true);
        define('_CON1swys135em856uv346_',true);
        define('_functionsqn72v3[701v[c124[m1c',true);
        define('_adminnb387w6[vn4', true);

        require_once INC.'/classes124vq32524s/DB2vq95mn42vnm704.php';       //PDO DB class
        require_once INC.'/classes124vq32524s/filter2vc63p5th.php';         //Filter class
        require_once INC.'/classes124vq32524s/XCSRFgrwhgr.php';             //XCSRF class
        require_once INC.'/classes124vq32524s/admin2v645n317vc05.php';      //admin
        //require_once INC.'/db-con2vpn2b569vn.php';                          //mysqli db
        require_once INC.'/functions2v3n51vn59mq07[5.php';                  //functions file

        $pdocon = PDODB::getConnection();                                      //getting connection
    }

