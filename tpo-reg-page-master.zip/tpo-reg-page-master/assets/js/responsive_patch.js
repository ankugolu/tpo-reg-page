$('.navbar-toggle').click(function () {
    console.log('toggle!');
    $('.navbar-collapse').toggle();

});